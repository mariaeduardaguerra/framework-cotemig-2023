let paragrafo = document.getElementById('paragrafoPrincipal');
let paragrafoMostrar = document.getElementById('paragrafoPrincipal').textContent;
document.getElementById("btnMostrar").addEventListener('click', mostrar);
document.getElementById("btnOcultar").addEventListener('click', ocultar);

function mostrar () {

    if(paragrafo === paragrafo) {
        paragrafo.textContent = paragrafoMostrar;
    }
    else{
        
    }
}

function ocultar () {

    if(paragrafo === paragrafo) {
        paragrafo.textContent = "";
    }
    else{
        
    }
}

